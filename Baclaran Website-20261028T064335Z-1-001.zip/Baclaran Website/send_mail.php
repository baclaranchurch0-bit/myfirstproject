<?php
declare(strict_types=1);

use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\PHPMailer;

header('Content-Type: application/json; charset=utf-8');

function respond(int $status, string $message): void
{
    http_response_code($status);
    echo json_encode(['message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    respond(405, 'Use the contact form to send a message.');
}

if (!is_file(__DIR__ . '/vendor/autoload.php')) {
    error_log('Contact form mailer is unavailable: Composer dependencies are not installed.');
    respond(503, 'The mail service is not ready. Please contact us through the official website.');
}

require __DIR__ . '/vendor/autoload.php';

$smtpHost = 'smtp.gmail.com';
$smtpUsername = 'kokoto0319@gmail.com';
$smtpPassword = 'axfodzzskgbypfyu';
$smtpFrom = 'kokoto0319@gmail.com';
$smtpPort = 587;
$smtpEncryption = 'tls';

if (!$smtpHost || !$smtpUsername || !$smtpPassword || !$smtpFrom || !filter_var($smtpFrom, FILTER_VALIDATE_EMAIL)) {
    error_log('Contact form mailer is not configured: SMTP environment variables are missing or invalid.');
    respond(503, 'The mail service is not configured yet. Please contact us through the official website.');
}

if (!in_array($smtpEncryption, ['tls', 'ssl'], true) || $smtpPort < 1 || $smtpPort > 65535) {
    error_log('Contact form mailer is not configured: SMTP encryption or port is invalid.');
    respond(503, 'The mail service is not configured yet. Please contact us through the official website.');
}

if (trim((string) ($_POST['website'] ?? '')) !== '') {
    respond(400, 'The form could not be submitted. Please reload the page and try again.');
}

$name = trim((string) ($_POST['name'] ?? ''));
$email = trim((string) ($_POST['email'] ?? ''));
$subject = trim((string) ($_POST['subject'] ?? ''));
$message = trim((string) ($_POST['message'] ?? ''));
$allowedSubjects = [
    'Website feedback',
    'Historical information',
    'Accessibility',
    'Virtual-tour issue',
    'Research inquiry',
];

if (
    $name === ''
    || mb_strlen($name) > 100
    || !filter_var($email, FILTER_VALIDATE_EMAIL)
    || mb_strlen($email) > 254
    || !in_array($subject, $allowedSubjects, true)
    || $message === ''
    || mb_strlen($message) > 10000
) {
    respond(422, 'Please check your name, email, subject, and message, then try again.');
}

session_start();
$now = time();
if (isset($_SESSION['contact_last_sent']) && $now - (int) $_SESSION['contact_last_sent'] < 15) {
    respond(429, 'Please wait a few seconds before sending another message.');
}

$escape = static fn (string $value): string => htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$safeName = $escape($name);
$safeEmail = $escape($email);
$safeSubject = $escape($subject);
$safeMessage = nl2br($escape($message));

$mailer = new PHPMailer(true);
try {
    $mailer->isSMTP();
    $mailer->Host = $smtpHost;
    $mailer->SMTPAuth = true;
    $mailer->Username = $smtpUsername;
    $mailer->Password = $smtpPassword;
    $mailer->SMTPSecure = $smtpEncryption === 'ssl'
        ? PHPMailer::ENCRYPTION_SMTPS
        : PHPMailer::ENCRYPTION_STARTTLS;
    $mailer->Port = $smtpPort;
    $mailer->CharSet = PHPMailer::CHARSET_UTF8;
    $mailer->setFrom($smtpFrom, 'Baclaran Church Website');
    $mailer->addAddress('kokoto0319@gmail.com');
    $mailer->addReplyTo($email, $name);
    $mailer->isHTML(true);
    $mailer->Subject = "Website contact: {$subject}";
    $mailer->Body = "<h2>Contact form message</h2><p><strong>Name:</strong> {$safeName}</p><p><strong>Email:</strong> {$safeEmail}</p><p><strong>Subject:</strong> {$safeSubject}</p><p><strong>Message:</strong><br>{$safeMessage}</p>";
    $mailer->AltBody = "Contact form message\n\nName: {$name}\nEmail: {$email}\nSubject: {$subject}\n\nMessage:\n{$message}";
    $mailer->send();
    $_SESSION['contact_last_sent'] = $now;
    respond(200, 'Thanks, your message was sent successfully.');
} catch (Exception $error) {
    error_log('Contact form email delivery failed: ' . $error->getMessage());
    respond(502, 'We could not send your message right now. Please try again later.');
}
