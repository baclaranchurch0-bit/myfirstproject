const pageNames = {
  'index.html': 'home',
  'about.html': 'about',
  '3d_tour.html': 'tour',
  'features.html': 'heritage',
  'education.html': 'education',
  'gallery.html': 'gallery',
  'resource.html': 'resources',
  'contact.html': 'contact'
};
const page = pageNames[window.location.pathname.split('/').pop().toLowerCase()] || 'home';
const navigation = document.querySelector('.primary-nav');
const menuToggle = document.querySelector('.menu-toggle');

document.querySelectorAll('[data-nav]').forEach((link) => {
  const current = link.dataset.nav === page;
  link.classList.toggle('is-current', current);
  if (current) link.setAttribute('aria-current', 'page');
});

if (navigation && menuToggle) {
  menuToggle.addEventListener('click', () => {
    const isOpen = menuToggle.getAttribute('aria-expanded') === 'true';
    menuToggle.setAttribute('aria-expanded', String(!isOpen));
    menuToggle.setAttribute('aria-label', isOpen ? 'Open menu' : 'Close menu');
    navigation.classList.toggle('is-open', !isOpen);
  });
}

const year = document.querySelector('#current-year');
if (year) year.textContent = new Date().getFullYear();

const tourDescription = document.querySelector('#tour-description');
const tourMap = document.querySelector('#tour-map');
const stopButtons = [...document.querySelectorAll('.stop-button')];

if (tourDescription && tourMap && stopButtons.length) {
  const tourStops = {
    facade: {
      title: 'Main facade',
      src: 'https://www.google.com/maps/embed?pb=!4v1793014491009!6m8!1m7!1sCAoSF0NJSE0wb2dLRUlDQWdNQ2drSWFJMXdF!2m2!1d14.53142791238849!2d120.9949514726336!3f354.46619636717867!4f10.092403337541796!5f0.4000000000000002',
      description: 'The church is identified as Modern Romanesque by its official architecture guide. Explore the exterior in this Google Maps Street View panorama.'
    },
    nave: {
      title: 'Nave',
      src: 'https://www.google.com/maps/embed?pb=!4v1793014607166!6m8!1m7!1sCAoSF0NJSE0wb2dLRUlDQWdJQzRuWmJpMHdF!2m2!1d14.53135771875053!2d120.995291911346!3f64.97345078024172!4f2.7028370261030403!5f0.7820865974627469',
      description: 'The nave is the main body of the church where devotees gather for prayer and worship. This is an available Google Maps Street View panorama.'
    },
    altar: {
      title: 'Main altar',
      src: 'https://www.google.com/maps/embed?pb=!4v1793014631671!6m8!1m7!1sCAoSFkNJSE0wb2dLRUlDQWdJRGN0NHpuT3c.!2m2!1d14.53141034182768!2d120.9954856721808!3f85.47958183732682!4f4.5349239867452695!5f0.7820865974627469',
      description: 'The main altar includes the shrine’s icon and its retable. View this Google Maps panorama respectfully; worshippers’ privacy and religious practice take priority.'
    }
  };

  stopButtons.forEach((button) => {
    button.addEventListener('click', () => {
      const stop = tourStops[button.dataset.stop];
      if (!stop) return;
      tourMap.src = stop.src;
      tourMap.title = `Google Maps Street View: ${stop.title}`;
      tourDescription.textContent = stop.description;
      stopButtons.forEach((stopButton) => {
        const selected = stopButton === button;
        stopButton.classList.toggle('is-selected', selected);
        stopButton.setAttribute('aria-pressed', String(selected));
      });
    });
  });
}

const filterButtons = [...document.querySelectorAll('.filter-button')];
const galleryCards = [...document.querySelectorAll('.gallery-card')];
filterButtons.forEach((button) => {
  button.addEventListener('click', () => {
    const filter = button.dataset.filter;
    filterButtons.forEach((filterButton) => {
      const selected = filterButton === button;
      filterButton.classList.toggle('is-active', selected);
      filterButton.setAttribute('aria-pressed', String(selected));
    });
    galleryCards.forEach((card) => {
      card.hidden = filter !== 'all' && card.dataset.category !== filter;
    });
  });
});

const imageDialog = document.querySelector('.image-dialog');
if (imageDialog) {
  const dialogImage = imageDialog.querySelector('.dialog-image');
  const dialogTitle = imageDialog.querySelector('#dialog-title');
  const dialogDescription = imageDialog.querySelector('#dialog-description');
  galleryCards.forEach((card) => {
    card.addEventListener('click', () => {
      dialogTitle.textContent = card.dataset.title;
      dialogDescription.textContent = card.dataset.description;
      dialogImage.src = card.querySelector('img').src;
      dialogImage.alt = card.querySelector('img').alt;
      dialogImage.className = `dialog-image ${[...card.classList].filter((name) => name.startsWith('image-')).join(' ')}`;
      imageDialog.showModal();
    });
  });
  imageDialog.querySelector('.dialog-close').addEventListener('click', () => imageDialog.close());
  imageDialog.addEventListener('click', (event) => {
    if (event.target === imageDialog) imageDialog.close();
  });
}

const contactForm = document.querySelector('#contact-form');
if (contactForm) {
  contactForm.addEventListener('submit', (event) => {
    event.preventDefault();
    const feedback = document.querySelector('#form-feedback');
    const submitButton = contactForm.querySelector('[type="submit"]');
    submitButton.disabled = true;
    feedback.textContent = 'Sending your message…';

    fetch(contactForm.action, {
      method: 'POST',
      body: new FormData(contactForm),
      headers: { Accept: 'application/json' }
    })
      .then(async (response) => {
        const result = await response.json();
        if (!response.ok) throw new Error(result.message || 'Your message could not be sent. Please try again.');
        feedback.classList.remove('is-error');
        feedback.textContent = result.message;
        contactForm.reset();
      })
      .catch((error) => {
        feedback.classList.add('is-error');
        feedback.textContent = error.message || 'Unable to reach the mail server. Please try again later.';
      })
      .finally(() => {
        submitButton.disabled = false;
      });
  });
}
